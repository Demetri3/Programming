﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*ProgrammingAssignment1_DD.cs calculates tax on purchased items and average speed
 * author: Dion Demetrius
 * Version: 1
 */
namespace ProgrammingAssignment1_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            //Part A:

            // Input
            double HST = 0.15; // Amount of tax
            double cost; // Cost of purchase
            double tip; // Tip amount
            double total; // Total
            double hstCost; // Tax amount 
            

            // Algorithm

            //Promt for cost
            Console.Write("What was the cost of your last purchase: ");
            cost = Convert.ToInt32(Console.ReadLine());

            //Prompt for tip
            Console.Write("What is the amount you have tipped: ");
            tip = Convert.ToInt32(Console.ReadLine());

            //Tax added to cost and tip
            hstCost = (cost + tip)* HST;

            //Total
            total = (cost + tip * hstCost);


            Console.WriteLine("\n\n\t Thank you for patronizing out store.");
            Console.WriteLine("\t ********************************");
            Console.WriteLine("\n\t\t Cost of meal - {0:c2}", cost);
            Console.WriteLine("\n\t\t Tip amount - {0:c2}", tip);
            Console.WriteLine("\n\t\t HST (15%) - {0:c2}", hstCost);
            Console.WriteLine("\n\t\t Total Amount - {0:c2}", total);
            Console.WriteLine("\n\n\t    Please Visit us again soon");
            Console.WriteLine("\t ********************************");


            Console.Write("\n\n\n Press any key to close the application");
            //Used to keep the application open
            Console.ReadKey();
        }
    }
}
