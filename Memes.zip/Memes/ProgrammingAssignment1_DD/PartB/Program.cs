﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartB
{
    class Program
    {
        static void Main(string[] args)
        {
            //Input
            double distance; // Distance traveled
            double time; // Amount of time it took to travel the distance
            double speed; // Total speed

            //Algorithm
            Console.Write("Enter distance in kilometers: ");
            distance = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Time in hours: ");
            time = Convert.ToInt32(Console.ReadLine());

            speed = (distance / time);

            //Speed traveled
            Console.WriteLine("Your total speed traveled would be: {0:F2}mph", speed);

            //Used to keep the application open
            Console.Write("Press any key to close the application");
            Console.ReadKey();
        }
    }
}
