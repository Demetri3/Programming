﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SphereVolume
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaration and initialization
            double pi = 3.14; //Represents pi
            double radius; // Represents the radius of a circle
            double volume; //Represents the area of a sphere
            

            //Input
            Console.Write("Enter the radius of the Sphere: ");
            radius = Convert.ToDouble(Console.ReadLine()); //or convert.Toint32

            //Calculate Volume
            volume = 4.0 / 3 * pi * radius * radius * radius;

            //Clear the screen
            Console.Clear();

            //Print the Volume
            Console.WriteLine("The volume of the sphere with radius {0:F3} is {1:F3}"
                , radius, volume);

            Console.Write("\n\n\n Press any ley to close the application.");
            //used to keep the application open
            Console.ReadKey();

        }
    }
}
