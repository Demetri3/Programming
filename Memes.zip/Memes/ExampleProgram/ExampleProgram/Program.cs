﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* Program.cs its a simple application
 * author: Dion Demetrius
 * version:1
 */


namespace ExampleProgram
{
    class Program
    {
        //Signature (declaration of main meathod)
        static void Main(string[] args)
        {
            Console.WriteLine("This is the first program of week2");

            Console.WriteLine("Press any key to close the application");
            //Used to keep the console open
            Console.ReadKey();
        }
    }
}
