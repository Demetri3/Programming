﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleArea
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaration and Initializations
            double radius; //Represents the radius of the circle

            double area; //Represents the area of the circle

            radius = 2.3;

            //Calculate area
            area = 3.14159 * radius * radius;

            //Print the area of the circle
            Console.WriteLine("************************************************************");
            Console.WriteLine("Original Output");
            Console.WriteLine("The area of the circle with radius(" + radius + 
                ") is; " + area);

            Console.WriteLine("\n\n\n\t Formatted Output");
            Console.WriteLine("\t the area of the circle with radius ({0:F2}) is: {1:F2}", radius, area);
            //For currency change F to C in placeholder format
            Console.WriteLine("\n\n\n Press any key to close the application");
            //Used to keep the console open
            Console.ReadKey();
        }
    }
}
