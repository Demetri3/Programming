﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathClassDemo_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Declarations
            //Declarations and Initilizations
            int varA = 1;
            int varB = 6;
            int varC = 1;
            double result; //represents the result of the expression
            #endregion

            #region Example1
            //Example 1: calculate tje expression
            //Note: meathods of the math class are ***STATIC***
            // thus we must write Math.()
            // Calculate the equation/expression
            result = -varB + Math.Sqrt(Math.Pow(varB, 2) - 4 * varA * varC) / (2 * varA);

            //Print answer
            Console.Write("Your result is {0:F2}", result);

            #endregion

            #region Example 2
            //Example 2: Find the area of the circle
            double radius = 2.2; // represents the radius of the circle
            double area; // represents the area of the circle

            //Calculate the area of the circle
            // Area = PI * R * R

            area = Math.PI * Math.Pow(radius,2);

            //Print the area of the circle
            Console.Write("\nThe area of the circle with the radius of {0} is {1}", radius, area);

            #endregion

            #region Example 3
            // Call the static meathod Multiply
            Console.WriteLine("\n67 Multiplied by 13 is: {0}", Multiply(67, 13));

            //Pass two random numbers between 1 and 100 to the multiply meathod
            //Note: Meathods of the random class are ***NOT STATIC***
            // thus we must create an object variable in order to call them
            //Declare an object variable of type random
            Random rng = new Random();

            // Generate the two values
            int value1 = rng.Next(1, 100);
            int value2 = rng.Next(1, 100);

            Console.WriteLine("{0} multiplied by {1} is: {2}", value1, value2, Multiply(value1, value2));
            #endregion

            Console.Write("\n\nPress any key to exit");
            Console.ReadKey();
        }

        public static double Multiply (double param1 , double param2)
        {
            return param1 * param2;
        }
        

    }
}


//1. The math class is 100% static : all meathods are static
//2. This class has many meathods that you can use to perform mathmatical operations: 
//   such as finding the absolute value of a number, or raising a number to a power of 4
//3. <ClassName>. [meathod name]
//ex. Math.pow(9,2): 81
//    Math.Sqrt(64): 8
//    * Math.Sqrt(-81) : invalid
//  9 * 9 :81
//  -9 * -9 : 81
// -----------------------
// Constant values
//----------------------- 
// Static meathods
//********************************
// <visibility> [static] return_type NameOfMeathod(...)
//********************************
// ClassName.<NameOfMeathod> / <NameOfMeathod>
// Assuming: main would call (static / non-static) meathod
//
// ---------------------
// Class : Student
//
//    >college name: Centennial College 
//
//         >name
//         > last name
//         > gpa
//
//  Student 1
//              John      smith        3.15
//  Student 2    
//              Betty     Ford         3.45
//
// Class: Guessing game
//
// > player 1
//      >Score
// > player 2
//      >Score
//
// * FindMaxScore
//------------------------------------
// Two Dimentional arrays (MATRIX)
// A Matrix with 2 rows and 3 colums
//  :      0    1   2
// 0:      6    7   8
// 1:     13    4  -1
//--------------------------
// A constant is a value that does not change during the runtime
// Example: PI
// public const int NAME_OF_CONSTANT
//
// TwoDarr.Rank: represents the number of dimensions
// TwoDArr.Length: represents the number of colums
//
//
//
//
//