﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoArrayDemo
{
    class Program
    {

        public const int MAX_NUM_OF_ROWS = 2;
        public const int MAX_NUM_OF_COLS = 3;

        static void Main(string[] args)
        {
            //Declarations and Initilizations
            int[,] matrix = new int[MAX_NUM_OF_ROWS, MAX_NUM_OF_COLS];

            //Print Rank and Length
            Console.WriteLine("The Rank of matrix is (the number of dimensions)", + matrix.Rank);
            Console.WriteLine("The total number of elements in the matrix", + matrix.Length);

            //Input
            //Repeat for all rows in the matrix
            for (int iRow = 0; iRow < matrix.Rank; iRow++)
            {
                //Repeat for all colums in matrix
                //Note: matrix.GetLength(0) returns the number of elements in the second dimension
                for(int iCol = 0; iCol < matrix.GetLength(1); iCol++)
                {
                    Console.Write("\nEnter matrix [{0}],[{1}]:", iRow, iCol);
                    matrix[iRow,iCol] = Int32.Parse(Console.ReadLine());

                }

            }

            Console.Clear();

            //Output
            //Repeat for all rows in the matrix
            for (int iRow = 0; iRow < matrix.Rank; iRow++)
            {
                //Repeat for all colums in matrix
                for (int iCol = 0; iCol < matrix.GetLength(1); iCol++)
                {
                    Console.Write(" {2} ", iRow, iCol, matrix[iRow, iCol]);

                }
                //Move cursor to the next line
                Console.WriteLine("");
            }


            Console.WriteLine("Press any key to exit");
            Console.ReadKey();




        }
    }
}
