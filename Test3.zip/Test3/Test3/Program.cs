﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilizations
            int[] ArrA = new int[10]; // Represents the first array
            int[] ArrB = new int[10]; // represents the second array
            int userInput; //represents the intput of the user


            //Promt user for the number of elements in the array
            Console.WriteLine("Enter the number of elements in the array: ");
            userInput = Convert.ToInt32(Console.ReadLine());

           
            
            //Enter the values of the array
            Console.WriteLine("what is the values for ArrA?: ");
            userInput = Convert.ToInt32(Console.ReadLine());
       
            Console.WriteLine("what is the values for ArrB?: ");
            userInput = Convert.ToInt32(Console.ReadLine());

            // Call meathod to check if
            Equality();
        }
         
        public static bool Equality (int[] ArrA, int[] ArrB)
        {

            if (ArrA == ArrB)
            {
                Console.WriteLine("True");
            }
            if (ArrA != ArrB)
            {
                Console.WriteLine("False");
            }
            else
            {
                Console.WriteLine("Wrong Input");
                
            }
            
          
        }

        Console.WriteLine("Press any key to exit");
        Console.ReadKey();
    }
}
