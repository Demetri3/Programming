﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initializations
            
            int userOption; //Represents the user input
            double mn1; //Multiplication number 1
            double mn2; //Multiplication number 2

            char answer; //Correct answer


            //Input
            Console.WriteLine("Math Practice");
            Console.WriteLine("-------------");
            Console.WriteLine("A. Multiplication");
            Console.WriteLine("B. Division");
            Console.WriteLine("C. Exit");
            
      
            Console.Write("\t Enter a letter (a/b/c) case sensitive   >   ");

            // cast the string as a character
            userOption = Char.Parse(Console.ReadLine());

            //clear the screen 
            Console.Clear();

            
            
            if (userOption == 'a')
            { // if users option is a
                Console.WriteLine("Enter two numbers and the correct answer.");
                Console.WriteLine("Number 1");
                mn1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Number 2");
                mn2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Answer: ");
                answer = Convert.ToChar(Console.ReadLine());
                if (answer == 'x')
                {
                    Console.WriteLine("Correct!");
                    Console.WriteLine("Press Any key to exit");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Wrong! The correct answer is x");
                    Console.WriteLine("Press Any key to exit");
                    Console.ReadKey();
                }
            }  
            
            
            if (userOption == 'b')
            { // if users option is b
                Console.WriteLine("Enter two numbers and the correct answer.");
                Console.WriteLine("Number 1");
                mn1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Number 2");
                mn2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Answer: ");
                answer = Convert.ToChar(Console.ReadLine());
                if (answer == '/')
                {
                    Console.WriteLine("Correct!");
                    Console.WriteLine("Press Any key to exit");
                    Console.ReadKey();

                }
                if (answer == 0)
                {
                    Console.WriteLine("ZERO DIVISOR. PRESS ANY KEY TO CONTINUE");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Wrong! The correct answer is /");
                    Console.WriteLine("Press Any key to exit");
                    Console.ReadKey();
                    
                }

            }

            if (userOption == 'c')
            {

                Console.WriteLine("Press Any key to exit");
                Console.ReadKey();


   

            }

            else
            {
                Console.WriteLine("WRONG ENTRY.PRESS ANY KEY TO CONTINUE");
                Console.ReadKey();

            }



        }
    }
}
