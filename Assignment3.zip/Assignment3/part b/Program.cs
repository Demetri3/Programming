﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part_b
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declatrations
            int balance; // bank balance
            int years; // years of interest
            int interest; // interest rate
            int calc; //calculation
            int rate;

            // Promt user to enter bank balance
            Console.WriteLine("Enter the starting balance in your account:  ");
            balance = Convert.ToInt32(Console.ReadLine());

            //Promt user to enter number of years and interest rate
            Console.WriteLine("Enter number of years and interest rate: ");
            Console.Write("Enter year amount: ");
            years = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter interest rate: ");
            interest = Convert.ToInt32(Console.ReadLine());

            //Algorithm
            calc = balance * interest;

            rate = interest * years;
            
            Console.WriteLine("Starting balance: {0}", balance);

            Console.WriteLine("Interest payed over {0} year(s): {1}", years, rate);

            Console.WriteLine("End year balance: {0}", balance + rate);


            Console.WriteLine("Press any key to exit");
            Console.ReadKey();








        }
    }
}
