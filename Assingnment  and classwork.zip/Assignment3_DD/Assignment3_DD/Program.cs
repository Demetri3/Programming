﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilizations
            int[] numbers;
            int userSize;


            //Promt user for input
            Console.Write("Enter values between 0-10: ");
            userSize = Int32.Parse(Console.ReadLine());



            //if user value is not between 0 and 10
            if (userSize < 0)
            {
                Console.Write("Please try again.");
                userSize = Int32.Parse(Console.ReadLine());

            }

            if (userSize > 10)
            {
                Console.Write("Please try again.");
                userSize = Int32.Parse(Console.ReadLine());

            }



           












        }
    }
}
