﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassNotes_Mar._9_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            // Array Declaration
            int[] numList = new int[5];

            // Initilize the Array
            // arrayname[index]
            numList[0] = 100;
                  ...
            numList[4] = 78;
        }
    }
}
