﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilizations
            int[] numList;
            int userSize; // represents the size entered by the user
            


            // int[] numList = new int[5];



            //Array Initilization
            //numList[0] = 100;
            //numList[1] = 35;
            //numList[2] = -10;
            //numList[3] = 25;
            //numList[4] = 78;


            //print the elements of the array
            // Console.WriteLine("numList[" + 0 + "]:" +numList[0]);
            // Console.WriteLine("numList[" + 1 + "]:" +numList[1]);
            // Console.WriteLine("numList[" + 2 + "]:" +numList[2]);
            // Console.WriteLine("numList[" + 3 + "]:" +numList[3]);
            // Console.WriteLine("numList[" + 4 + "]:" +numList[4]);


            //What is length?
            //In an array the lenth propertie reflects the size of the array
            // ex. double[] costList = new double[200]
            // costList.length = 200

            //promt user to enter the size
            Console.WriteLine("enter the size of  the array (max 1000):");
            userSize = Int32.Parse(Console.ReadLine());

            //create an array object:
            numList = new int[userSize];



            //Repeat for all the elements of the array
            for (int index = 0; index < numList.Length; index++)
            {
                Console.WriteLine("numList[" + index + "]: " + numList[index]);
            }

            //user input
             for (int index = 0; index < numList.Length; index++)
            {
                Console.WriteLine("numList[" + index + "]: " + numList[index]);
                numList[index] = Int32.Parse(Console.ReadLine());
            }

            Console.WriteLine("**Elements of numList printed in reverse order**\n");

            //In reverse
            for (int index = 4; index >= 0; index--)
            {
                Console.WriteLine("numList[" + index + "]: " + numList[index]);
            }





            Console.Write("Press any key to close");
            Console.ReadKey();
        }
    }
}
