﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int userInput;
            int num = 0;


            //input
            Console.WriteLine("Enter any number: ");
            userInput = Convert.ToInt32(Console.ReadLine());
            

            //Loop
            while (num >= userInput)
            {
                Console.WriteLine("You have been in this loop {0} times", userInput);
                
   
            }//end of loop



            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
