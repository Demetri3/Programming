﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exersize2_Feb24_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int average; 

            //Repeat for each 
            for (int num = 300; num <= 400; num++)
            {
                if (num % 2 == 0)
                //Printing Number
                Console.WriteLine("Printing numbers: {0}", num);
            }//End of loop

            average = 100/50;

            Console.WriteLine("The Average of all the numbers is {0}", average);


            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
