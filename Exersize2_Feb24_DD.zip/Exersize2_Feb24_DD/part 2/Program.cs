﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int userInput;
            int num = 0;



            //Loop
            while (num >= 0)
            {
                Console.WriteLine("Enter a number: ");
                userInput = Convert.ToInt32(Console.ReadLine());
                userInput++;
                if (userInput == 5)
                {
                    Console.WriteLine("The total number of values entered is: {0}", userInput );
                        break;
                }
            }//end of loop



            Console.WriteLine("Press any key to exit");
            Console.ReadKey();

        }
    }
}
