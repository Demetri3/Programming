﻿/* Program.cs will convert all the lowercase letters in a string to their capital eqiivalents
 * author: Dion Demetrius
 *  
 */ 



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declararions and Initilization
            string sentence; // User will input an sentence
            do
            {// Repeat the loop

                //Input
                Console.Write("Enter a sentence: (Empty string to stop): ");
                sentence = Console.ReadLine();

                //Check if the user enters something
                if (sentence != "")
                {
                    // convert the string to an array of characters
                    // Note: the method toCharArray() converts a string to  an array of characters
                    char[] sentenceArr = sentence.ToCharArray();

                    for (int index = 0; index < sentenceArr.Length; index++)
                    {
                        // check if the element is a lowercase letter 
                        if (sentenceArr[index] >= 'a' && sentenceArr[index] <= 'z')
                        {
                            //check: ? sentenceArr[index] -= (char)32
                            //Convert the lowercase letter into a capital one
                            sentenceArr[index] = (char)(sentenceArr[index] - 32);
                        }
                    }
                    //convert the character array back to a string
                    string sentenceCapital = new string(sentenceArr);

                    Console.WriteLine("original sentence {0}", sentence);
                    Console.WriteLine("Capital sentence {0}", sentenceCapital);
                }


            } while (sentence != ""); //Repeat until the user enters an empty string
           

            Console.Write("Press any key to continue...");
            Console.ReadKey();

        }
    }
}
