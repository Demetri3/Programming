﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeathodDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilizations
            Program self = new Program();
            int userStars; // Represents the number of stars the user requests

            //call the meathod using self
            self.printStars();

            //call the PrintNStars method
            self.printNStars(10);
            self.printNStars(3);


            //Ask the user how many stars they want
            Console.Write("How many stars do you want?: ");
            userStars = Convert.ToInt32(Console.ReadLine());

            //Call the printNStars method
            //to print the number of stars the user wants
            self.printNStars(userStars);

            //Call the printNChars method
            //to print the number of SPECIFIED characters
            Console.WriteLine("***Print '?' 12 times***");
            self.printNChar('?', 12);


            Console.WriteLine("Press any key to exit: ");
            Console.ReadKey();

        }//end of main

        /// <summary>
        /// Prints 5 stars
        /// </summary>
        //when you want to call your meathod you have to create an object variable
        public void printStars()
        {
            {
               Console.WriteLine("*****");

            }
            
        }

       
        /// <summary>
        /// <param>
        /// PrintNStars prints the number of stars requested by the user 
        /// </param>
        /// <param name="numOfStars"
        /// </summary>
        /// 
         

        public void printNStars(int numOfStars)
        {
            for (int iStars = 0; iStars < numOfStars; iStars++)
            {
                //print stars
                Console.Write("*");

            }
            //line change after all the stars are printed
            Console.WriteLine();
        }


        /// <summary>
        /// printNChar prints the number of symbol(s) depending on the users requests
        /// </summary>
        /// <param name="symbol"> the character requested by the user</param>
        /// <param name="numOfSymbol"> the number of times that symbol is repeated</param>

        public void printNChar(char symbol, int numOfSymbol)   
            {//repeat fot the numOfSymbols
            for (int iChars = 0; iChars < numOfSymbol; iChars++)
            {
                //print the symbol
                Console.Write(symbol);

            }
            //line change after all the stars are printed
            Console.WriteLine();



        }


    }
}
