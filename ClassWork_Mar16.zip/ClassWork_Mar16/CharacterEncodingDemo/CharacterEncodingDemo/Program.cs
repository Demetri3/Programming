﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterEncodingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declararions and Initilization
            int numberLetter;
            char letter = 'P';

            int numberLetter1 = 33;
            char letter1;

            char lowerLetter; // Represents the lowercase version of the letter

            //1. Convert the letter to an intiger
            numberLetter = letter;

            //1. Print the number
            Console.WriteLine("The code for letter " + letter + " is: " + numberLetter);

            //2. Convert the integer to a letter
            //NOTE: there is a type cast from intiger to character
            letter1 = (char) numberLetter1;

            Console.WriteLine("The letter for code " + numberLetter1 + " is: " + letter1);

            //Convert a capital letter to its lowercase version
            // NOTE: the diffrerence bewteen a capital letter and its lower case version is 32 units
            
            Console.WriteLine("The lettercase letter for " + letter + " is: " + letter1);


            //Convert a capital letter to its lower case version
            lowerLetter = (char)(letter + 32);



            Console.Write("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
