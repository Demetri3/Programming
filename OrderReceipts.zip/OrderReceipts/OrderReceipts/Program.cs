﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderReceipts
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input
            string name; //Name of customer
            string streetAdress; //address
            string city; //city
            string state; //state
            string zipCode; //zipcode
            double quantity; //number of blenders purchased/ordered
            double salesTax; //amount of tax after the number blenders purchased
            double amountDue; //amount due before tax

            //Algorithm
            Console.Write("What is your name?");
            name = Console.ReadLine();

            Console.Write("What is your Street Adress?");
            streetAdress = Console.ReadLine();

            Console.Write("What city do you live in?");
            city = Console.ReadLine();

            Console.Write("What state do you live in?");
            state = Console.ReadLine();

            Console.Write("What is your zip code?");
            zipCode = Console.ReadLine();

            Console.Write("How many blenders do you want?");
            quantity = Convert.ToInt32(Console.ReadLine());

            amountDue = (quantity * 39.95);
            salesTax = (quantity * 39.95) * 0.07;

            //Display

            Console.WriteLine("\t ------------------------------------------");
            
            Console.WriteLine("\t\t Name: {0}", name);
            Console.WriteLine("\t\t City: {0}", city);
            Console.WriteLine("\t\t State: {0}", state);
            Console.WriteLine("\t\t ZipCode: {0}", zipCode);
            Console.WriteLine("\t\t Amount: {0}", quantity);
            
            Console.WriteLine("\t\t Before tax it will cost:{0}", amountDue);

            Console.WriteLine("\t\t Tax will be: {0}", amountDue * 0.07);

            Console.WriteLine("\t\t Total Net due is: {0}", amountDue + salesTax);

            Console.WriteLine("\t ------------------------------------------");

            Console.WriteLine("Press Any key to Exit");
            Console.ReadLine();
        }
    }
}
