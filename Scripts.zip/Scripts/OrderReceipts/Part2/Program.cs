﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Input
            double m1; // the mass of the planet
            double m2; // the mass of the moon
            double radius; // the distance between the moon and planet
            double gravity;
            double force;


            //Algorithm
            Console.Write("Enter the mass of a planet:");
            m1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the mass of a moon:");
            m2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the distance between the two masses");
            radius = Convert.ToInt32(Console.ReadLine());

            // The Gravitaional Constant is 
            gravity = 6.67E-11;

            //Answer
            force = (gravity * m1 * m2) / radius * 2;

            //Scientific Format
            Console.WriteLine("The gravatational force between these two masses is:");
            Console.WriteLine("result {0:E2}", force);
        }
    }
}
