﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderReceipts
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input
            string name; //Name of customer
            string streetAdress; //address
            string city; //city
            string state; //state
            string zipCode; //zipcode
            double quantity; //number of blenders purchased/ordered
            double salesTax; //amount of tax after the number blenders purchased
            double amountDue; //amount due before tax

            //Algorithm
            Console.Write("What is your name?");
            name = Console.ReadLine();

            Console.Write("What is your Street Adress?");
            streetAdress = Console.ReadLine();

            Console.Write("What city do you live in?");
            city = Console.ReadLine();

            Console.Write("What state do you live in?");
            state = Console.ReadLine();

            Console.Write("What is your zip code?");
            zipCode = Console.ReadLine();

            Console.Write("How many blenders do you want?");
            quantity = Convert.ToInt32(Console.ReadLine());

            amountDue = (quantity * 39.95);
            salesTax = (quantity * 39.95) * 0.07;

            Console.WriteLine("------------------------------------------");
            
            Console.WriteLine(name);
            Console.WriteLine(city);
            Console.WriteLine(state);
            Console.WriteLine(zipCode);
            Console.WriteLine(quantity);

            Console.WriteLine("Before tax it will cost:{0}", amountDue);

            Console.WriteLine("Tax will be: {0}", amountDue * 0.07);

            Console.WriteLine("Total Net due is: {0}", amountDue + salesTax);



            Console.WriteLine("Press Any key to Exit");
            Console.ReadLine();
        }
    }
}
