﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_DD
{
    class Program
    {
        static void Main(string[] args)
        {


            //Declarations and Initilization
            int[] numbers = new int[5];
            

            //Ask the user to enter the values for the following elements
            for (int index = 0; index < numbers.Length; index++)
            {
                Console.WriteLine("Enter a value for element [" + index + "]: ");
                numbers[index] = Int32.Parse(Console.ReadLine());


            }



            //Print the elements of the array
            Console.WriteLine("***Elements***");



            //repeat for all the elements of the arra


            for (int index = 0; index < numbers.Length; index++)
            {
                //Print the index and value                                     
                Console.WriteLine("Enter a value for element [" + index + "]: " + numbers[index]);

                for (index = 0; index >= numbers[index]; index++)   // (repeat from 0 to numbers[index])
                    {
                    // print star
                    Console.Write("*");
                    Console.ReadKey();
                    }


            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();

        }

      
    }
}
