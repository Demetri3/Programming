﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace partB
{
    class Program
    {
        static void Main(string[] args)
        {

            //create a string to represent the phone #
            string telString;

            //Convert phone # to (ASGII) ex. 6 --> 48
            switch    
            {
                

            }


        }
    }
}
