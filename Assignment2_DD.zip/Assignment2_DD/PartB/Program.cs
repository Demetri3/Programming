﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartB
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilization
            int userInput; // Represents user input 
            double r1; //Value of resistor 1 for option 1
            double r2; // value of resistor 2 for option 1
            double rt; //Total resistance for option 1
            double rv; //Risistor value for option 2
            double v; // Represents voltage for option 2
            double current; // Total current for option 2

            // Input
            Console.WriteLine("Pick one of the 3 options (A/B/C)");

            Console.WriteLine("1. Option A");
            Console.WriteLine("2. Option B");
            Console.WriteLine("3. Option C");

            // Clears words above
           

            //User inputs an option
            userInput = Int32.Parse(Console.ReadLine());

            if (userInput == 1)
            {

                Console.Write("Enter value of your first resistor ");
                r1 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter value of your second resistor ");
                r2 = Convert.ToInt32(Console.ReadLine());

                //Calculation of parallel resistance
                rt = 1 / r1 + 1 / r2;

                Console.WriteLine("The value of the two resistors in parallel is: {0} ", rt);

                Console.WriteLine("press any key to exit");
                Console.ReadKey();

            }
            else if (userInput == 2)
            {
                Console.Write("Enter the Value of the resistor:  ");
                rv = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter the Voltage of the resistor:  ");
                v = Convert.ToInt32(Console.ReadLine());

                // Calculation of current
                current = rv * v;

                Console.WriteLine("The current flowing in the resistor would be: {0}", current);

                Console.WriteLine("press any key to exit");
                Console.ReadKey();

            }
            else if (userInput == 3)
            {
                Console.WriteLine("Goodbye, Hit any key to exit");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Wrong Selection, Hit any key to exit. Goodbye.");
                Console.ReadKey();
            }


        }
    }
}
