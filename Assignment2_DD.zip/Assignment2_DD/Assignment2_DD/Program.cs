﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilization
            double weight;
            double height;
            double BMI;
            
            //Input
            //Prompt user for input for weight
            Console.Write("Enter your weight in kilograms:  ");
            weight = Int32.Parse(Console.ReadLine());

            //Prompt user for imput in height
            Console.Write("Enter your height in meters:  ");
            height = Int32.Parse(Console.ReadLine());

            //BMI calculation

            BMI = weight / height * 2;

            //Display BMI
            Console.WriteLine("Your BMI is: {0} ", BMI);

            //Program Exit
            Console.WriteLine("Press any key to close the application");
            Console.ReadKey();


        }
    }
}
