﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_6_DD
{
    class Program
    {
        

        static void Main(string[] args)
        {
            //Declarations and Initilizations
            //Note: Students = iRow, Tests = iCol
            int[] students = new int[10];
            int[] tests = new int[10];

            //Input
            //Prompt teacher for the number of students he/she has
            //Repeat for all rows in the martrix
            for(int iRow = 0; iRow < students.Rank; iRow++)
            {
                for(int iCol= 0; iCol <= students.GetLength(1); iCol++)
                {
                    Console.WriteLine("Student#{0} ", students);
                    students[iRow] = Int32.Parse(Console.ReadLine());

                }
            }

            //Prompt teacher for the number of tests he/she has 
            for (int iRow = 0; iRow < tests.Rank; iRow++)
            {
                for(int iCol = 0; iCol < tests.GetLength(1); iCol++)
                {
                    Console.Write("Grade for student {0} is {1}", students, tests);
                    tests[iCol] = Int32.Parse(Console.ReadLine());
                }
                
            }

            Console.ReadKey();


            //Print
         
            






            Console.WriteLine("Press any key to exit");
            Console.ReadKey();

        }


        public static void CalcTotal()
        {
           


        }
    }
}
