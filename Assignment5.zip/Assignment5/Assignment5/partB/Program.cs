﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace partB
{
    class Program
    {
        static void Main(string[] args)
        { // Start of main
           


            Program self = new Program(); 

            SalesLetter(); // Call the meathod created bellow


            Console.Write("\nPress any key to exit");
            Console.ReadKey();
                                  
        } // End of Main

        public static void SalesLetter()
        { // Start of sales letter meathod

            var sentences = new string[]  // Array that will hold the sentences
            {
                "Buy it today!", "You have made a great purchase!" , "You will not regret your decision!",
                "Make sure to tell all your friends!", "Don't forget to come back tomorrow", "Hurry its a limited time sale only!"
            };

            //Declare an object variable
            var rng = new Random();

            var a = rng.Next(sentences.Length); // a random number 
            var b = rng.Next(sentences.Length);
            var c = rng.Next(sentences.Length);

            Console.Write("Press any key to generate a Sales Pitch: ");
            Console.ReadKey();

            Console.Write($"Your choices are: \n{sentences[a]}, \n{sentences[b]}, \n{sentences[c]} ");

            

        } // End of sales letter meathod


    }
}
