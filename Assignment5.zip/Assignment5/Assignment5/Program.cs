﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class Program
    {
        static void Main(string[] args)
        {//Start of main
            





        }//End of Main

        public void ShowMenu()
        {
            //Declarations
            int userInput;
            int radius;
            int degrees;
            double area;
            double theta;


            //Menu
            Console.WriteLine("MENU");
            Console.Write("-------------");
            Console.WriteLine("S. Sector Area");
            Console.WriteLine("E. Exit");
            userInput = Convert.ToChar(Console.ReadLine());


            //
            Console.Write("Choose one of the 2 options: ");
            if (userInput == 's')
            {
                //Prompt for radius
                Console.Write("Enter the radius of a circle in cm: ");
                radius = Convert.ToInt32(Console.ReadLine());
                
                //Prompt for degrees
                Console.Write("Enter an angle in degrees: ");
                degrees = Convert.ToInt32(Console.ReadLine());


                //Calculate theta
                theta = (degrees * 3.14 / 180);

                //Calculate area
                area = (radius * 2 * theta) / 2;

                //Print solution
                Console.Write("The area of your circle is {0}", area);
                Console.ReadKey();

            }
            if (userInput == 'e')
            {
                Console.Write("Goodbye");
                Console.ReadKey();
                

            }
            else
            {
                Console.WriteLine("Wrong entry, Try again");
                Console.ReadLine();

                Console.Clear();
                ShowMenu();

            }
            


        }


    }
}
