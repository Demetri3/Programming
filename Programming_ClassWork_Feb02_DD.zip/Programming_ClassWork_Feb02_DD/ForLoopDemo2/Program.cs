﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoopDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaration and Initilization
            int total = 0; // represents the total of all number
            int count = 0; //Represents the count of all numbers between (0-100)
            double avg; // Represents the average of all numbers

            Console.WriteLine("Numbers divisible by 23 in range 1 to 100:  ");

            //Repeat for each number between (0-100)
            for (int number = 0; number < 101; number++)
            {
                //Add the number to the current total
                total += number;  //total = total + number;

                //update count
                count++; // ++count


                //print the number if it is divisible by 23
                if(number % 23 == 0)
                {
                    Console.WriteLine(number);
                }

                
            } // End of for loop

            //calculate average
            avg = (double) total / count;


            //print the total
            Console.WriteLine("\t* The total of all numbers between 0 to 100 is: {0} ", total);

            //print the average of all numbers
            Console.WriteLine("\t* The average of all numbers ({0}) between 0 to 100 is {1}:",count,  avg);

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();

        }
    }
}
