﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWork_Part2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initializations
            int userOption; //Represents the user input

            //Input
            Console.WriteLine("**This is the switch version**");
            Console.WriteLine("A. Option 1");
            Console.WriteLine("B. Option 2");
            Console.WriteLine("C. Option 3");
            Console.WriteLine("D. Option 4");


            Console.Write("\t Enter a letter (A/B/C/D) not case sensitive   >   ");

            // cast the string as a character
            userOption = Char.Parse(Console.ReadLine());

            //clear the screen 
            Console.Clear();

            switch (userOption) // Check the values for user option
            {
                case 'A': // if user option is 1
                case 'a':
                    Console.WriteLine("This is option A");
                    Console.WriteLine("This is the first option");
                    break;

                case 'B': // if user option is 2
                case 'b':
                    Console.WriteLine("This is option B");
                    Console.WriteLine("This is the second option");
                    break;

                case 'C': // if usre option is 3
                case 'c':
                    Console.WriteLine("This is option C");
                    Console.WriteLine("This is the third option");
                    break;

                case 'D': // if user option is 4
                case 'd':
                    Console.WriteLine("This is option D");
                    Console.WriteLine("This is the fourth option");
                    break;

                default: // if user inputs anything else
                    Console.WriteLine("Invalid Option Try again");
                    break;

            } // end of the switch

            Console.WriteLine("Press Any key to exit");
            Console.ReadKey();
        }
    }
}
