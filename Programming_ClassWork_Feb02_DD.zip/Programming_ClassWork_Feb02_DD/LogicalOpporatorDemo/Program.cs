﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicalOpporatorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declarations and Initilizations
            int userAge: //represents the age (0-100)

            // Input
            Console.Write("enter the age: ");
            userAge = Convert.ToInt32(Console.ReadLine());

            //Check the age range
            if (userAge > 0 && userAge < 2)
            {
                Console.WriteLine("Baby");
            }
            else if (userAge >= 3 && userAge <= 39)
            {
                Console.WriteLine("Young Adult");
            }
            else if (userAge >= 40 && userAge <= 59)
            {
                Console.WriteLine("Middle aged");
            }
            else if (userAge >= 60 && userAge <= 100)
            {
                Console.WriteLine("Old Adult");
            }
            else
            {
                Console.WriteLine("Faulty input. Must be between (0-100)");
            }

            Console.Write("Press any key to exit");
            Console.ReadKey();
        }
    }
}
