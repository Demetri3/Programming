﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoopDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Repeat for each line number
            for (int line = 9; line >= 0; line-- )
            { 
                // Printing line number
                Console.WriteLine("The Line number is:  ", + (line+1));
            } // End of for loop

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
