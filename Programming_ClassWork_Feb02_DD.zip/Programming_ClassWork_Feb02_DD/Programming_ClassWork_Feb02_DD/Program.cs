﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programming_ClassWork_Feb02_DD
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initializations
            int userOption; //Represents the user input

            //Input
            Console.WriteLine("1. Option A");
            Console.WriteLine("2. Option B");
            Console.WriteLine("3. Option C");
            Console.WriteLine("4. Option D");


            Console.Write("\t Enter an option");

            userOption = Int32.Parse(Console.ReadLine());

            if (userOption == 1) //if user chooses 1
            {
                Console.WriteLine("This is option A");
                Console.WriteLine("This is the first option");
            }
            else if (userOption == 2) // if user chooses 2
            {
                Console.WriteLine("This is option B");
                Console.WriteLine("This is the second option");

            }
            else if (userOption == 3) // if user chooses 3
            {
                Console.WriteLine("This is option C");
                Console.WriteLine("This is the third option");

            }
            else if (userOption == 4) // if the user chooses 4
            {
                Console.WriteLine("This is option D");
                Console.WriteLine("This is the fourth option");
            }
            else // if user chooses anything else
            {
                Console.WriteLine("Invalid Option. You must choose one of the four options");
            }
            Console.WriteLine("Enter any key to");
            Console.ReadLine();
        }
    }
}
