﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarations and Initilizations
            int userValue; //represents the value the user enters
            int total = 0;  // represents the sum of the value the user enters
            int count = 0; // represents the number of values the user entered
            int maxValue = 0;  
            int minValue = 0;

            #region FIRST NUMBER
            //TO DO:  ADD A LOOP TO MAKE SURE THE USER ENTERS A POSITIVE NUMBER
            //Ask the user for the first integer
            Console.Write("Enter positive whole number: (negative number to stop)");

            //Ask the user to enter a value
            userValue = int.Parse(Console.ReadLine());

            // assign the positive integer to both minimum and maximum
            minValue = maxValue = userValue;

            //update total
            total += userValue;
            count++;
            #endregion

            while (true)  //Repeat
            {
                Console.Write("Enter a whole number: (negative number to stop)");
                //Ask the user to enter a value
                userValue = int.Parse(Console.ReadLine());

                if (userValue > 0) //Checks if value is positive
                {
                    total += userValue; //update total
                    count++; //Update the count

                    if (userValue < minValue) // check if it is smaller than the smallest value
                    {
                        minValue = userValue;
                    }
                    if (userValue > maxValue) // check if greater than currect maximum
                    {
                        maxValue = userValue;
                    }
                }
                else
                {
                    break; // end the infinite loop
                }


            } //until the user enters a negative number



            Console.WriteLine("The average of all numbers are: {0:F2} ", (double)total / count);
            Console.WriteLine("The minimum value is {0} and the max value is {1}", minValue, maxValue);







            Console.Write("Press any key to exit");
            Console.ReadKey();
                
                   
        }
    }
}
